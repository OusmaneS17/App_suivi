from django.contrib import admin
from django.urls import path, include
from . import views
from django.conf import settings
from django.conf.urls.static import static



urlpatterns = [
    
    path('', views.sing_in, name='sing_in'),
    path('register', views.sing_up, name='sing_up'),
    path('logout', views.log_out, name='log_out'),
    path('forgot-password', views.forgot_password, name='forgot_password'),
    path('update-password', views.update_password, name='update_password'),

]